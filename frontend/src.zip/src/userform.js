import {useState} from "react";
import axios from "axios";
const UserForm=()=>{
    const[formdata,setFormdata]=useState({
        'username':'',
        'password':'',
    })
    const handlesubmit=(e)=>{
        e.preventDefault();
        console.log(formdata)
        axios.post('http://localhost:5000/adduser',{formdata}).then((result)=>{console.log(result.body)})
    }
    return(
        <>
        <form onSubmit={handlesubmit}>
            <label>Username</label>
            <input type="text" name="username" onChange={(e)=>setFormdata({...formdata,username:e.target.value})}/>
            <br/>
            <label>Password</label>
            <input type="password" name="password" onChange={(e)=>setFormdata({...formdata,password:e.target.value})}/>
            <br/>
            <input type="submit" value="submit"/>
            <br/>
        </form>
        </>
    )
}
export default UserForm;